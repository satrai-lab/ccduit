FED_BROKER = "localhost"
FED_PORT = 1884
CONTEXT_BROKER_URL = "http://localhost:1028/ngsi-ld/v1/entities"
FEDERATION_ID = "urn:ngsi-ld:Federation:Federation1"
