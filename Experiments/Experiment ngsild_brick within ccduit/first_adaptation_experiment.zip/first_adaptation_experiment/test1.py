import os
import sys
import subprocess
import time
import shutil
import psutil
import multiprocessing
import threading
import plot
import json
from datetime import datetime, timezone
import json
import paho.mqtt.client as mqtt
import requests
from multiprocessing import Process
import time
# --- Import Interaction_Handling_Service from Federation1 ---
# Construct Federation1’s path.
# --- Import Policy_Management_Service from Federation2 ---
# Construct Federation2’s path.
modules_path_2 = os.path.join(os.getcwd(), './Federation2')
if os.path.exists(modules_path_2):
    # Again, insert at the beginning of sys.path.
    sys.path.insert(0, modules_path_2)
else:
    raise FileNotFoundError(f"Federation2 path not found: {modules_path_2}")

# Now import Policy_Management_Service.
import Policy_Management_Service
import policy_monitoring as policy_monitoring2



# Windows flag to suppress new window creation
CREATE_NO_WINDOW = 0x08000000

FED_BROKER = "localhost"
FED_PORT = 1885
CONTEXT_BROKER_URL = "http://localhost:1029/ngsi-ld/v1/entities"
FEDERATION_ID = "urn:ngsi-ld:Federation:Federation2"

def store_policy(policy):
    # print(json.dumps(policy))
    if policy is None:
        print("Policy is None, skipping storage.")
        return
    if isinstance(policy,str):
        policy=json.loads(policy)
        # print(policy)
    headers = {'Content-Type': 'application/json'}
    policy_id = policy.get('id', None)
    if policy_id is None:
        print("Policy ID is None, cannot store policy.")
        return

    print(f"Processing policy with ID: {policy_id}")

    # Extract the lastModified timestamp from the incoming policy
    incoming_last_modified_str = policy.get('modificationPolicy', {}).get('value', {}).get('lastModified', None)
    if incoming_last_modified_str is None:
        print("Incoming policy does not have a lastModified timestamp.")
        return

    # Convert incoming lastModified to UTC datetime
    try:
        incoming_last_modified = datetime.strptime(incoming_last_modified_str, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except ValueError:
        print(f"Invalid lastModified format in incoming policy: {incoming_last_modified_str}")
        return

    try:
        # Attempt to retrieve the existing policy from the Context Broker
        response = requests.get(f"{CONTEXT_BROKER_URL}/{policy_id}")
        if response.status_code == 200:
            existing_policy = response.json()
            existing_last_modified_str = existing_policy.get('modificationPolicy', {}).get('value', {}).get('lastModified', None)

            if existing_last_modified_str:
                # Convert existing lastModified to UTC datetime
                try:
                    existing_last_modified = datetime.strptime(existing_last_modified_str, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                except ValueError:
                    print(f"Invalid lastModified format in existing policy: {existing_last_modified_str}")
                    return

                # Compare the timestamps
                if incoming_last_modified > existing_last_modified:
                    print(f"Incoming policy is newer. Updating policy {policy_id}.")
                    # Delete the existing policy
                    delete_response = requests.delete(f"{CONTEXT_BROKER_URL}/{policy_id}")
                    delete_response.raise_for_status()
                    print(f"Policy {policy_id} deleted successfully.")
                else:
                    print(f"Existing policy {policy_id} is up-to-date. No changes made.")
                    return

        # Store the incoming policy
        response = requests.post(CONTEXT_BROKER_URL, json=policy, headers=headers)
        response.raise_for_status()
        print(f"Policy {policy_id} stored successfully.")
    except requests.exceptions.RequestException as e:
        print(f"Failed to process policy {policy_id}: {e}")

def publish_policy(policy_entity,topic, mosquitto_address,port=1883):
    """
    Publishes a policy entity to the specified Mosquitto MQTT broker topic.

    Args:
        policy_entity (dict): The policy entity as a Python dictionary.
        mosquitto_address (str): The address of the Mosquitto broker (e.g., "localhost" or "192.168.1.100").
        topic (str, optional): The MQTT topic to publish to. Defaults to "fred/policy".
    """
    
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    # Create MQTT Client
    client = mqtt.Client()
    client.on_connect = on_connect

    # Connect to Mosquitto Broker
    try:
        client.connect(mosquitto_address,port)
    except Exception as e:
        print(f"Error connecting to MQTT broker: {e}")
        return

    # Start MQTT client loop in the background
    client.loop_start()
   
    # Convert entity to JSON string
    payload = json.dumps(policy_entity)
    start_time=time.perf_counter_ns()
    print(f"start time: {start_time}")  
    # threading.Thread(target=log_time, args=(start_time,)).start()
    # Publish message with QoS 2 for persistence
    result = client.publish(topic, payload, qos=2,retain=True)

    # Check if message was sent successfully
    if result[0] == 0:
        print(f"Policy sent to topic {topic}")
    else:
        print(f"Failed to send policy to topic {topic}")

    # Disconnect after publishing
    client.loop_stop()
    client.disconnect()

def add_extra_slashes(url):
    return url.replace("/", "//")

def create_publish_policy(policy_ID,name,description,providerFederation_ID,permittedContextTypes,
                            sharingRules,modifiedBy,Geographic_Restrictions,mosquitto_address=FED_BROKER,mosquitto_Port=FED_PORT):
    # start_time=time.time_ns()
    
    modified_url = add_extra_slashes(CONTEXT_BROKER_URL)
    # Process(target=register_start_times, args=(start_time,)).start()
    policy_Entity = {
            "id": f"urn:ngsi-ld:ContextPolicy:{policy_ID}",
            "type": "ContextPolicy",
            "name": {
              "type": "Property",
              "value": f"{name}"
            },
            "description": {
              "type": "Property",
              "value": f"{description}"
            },
            "providerFederation": {
              "type": "Relationship",
              "object": f"urn:ngsi-ld:Federation:{providerFederation_ID}"
            },
            "permittedContextTypes": {
              "type": "Property",
              "value": permittedContextTypes
            },
            "ContextBrokerURL": {
              "type": "Property",
              "value": f"{modified_url}"
            },
            "sharingRules": {
              "type": "Property",
              "value": sharingRules
            },
            "modificationPolicy": {
              "type": "Property",
              "value": {
                "lastModified": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "modifiedBy": modifiedBy
              }
            },
            "Geographic_Restrictions": {
              "type": "Property",
                "value": Geographic_Restrictions
            }
    }
    Process(target=store_policy,args=(policy_Entity,)).start()
    # store_policy(policy_Entity)
    # file_path=f"{policy_ID}.jsonld"
    # # Write policy to file with proper JSON-LD formatting
    # with open(file_path, "w") as f:
    #     json.dump(policy_Entity, f, indent=2)  # Use indent for readability
    publish_policy(policy_Entity,f"Federation/urn:ngsi-ld:Federation:{providerFederation_ID}/Policy/urn:ngsi-ld:ContextPolicy:{policy_ID}",
                  mosquitto_address,mosquitto_Port)
    



  
def main():
    multiprocessing.Process(target=policy_monitoring2.main).start()
    time.sleep(5)
    
        
    create_publish_policy("Policy2", "Policy2", "This policy allows sharing and forwarding data publicly", "Federation2",
                                                    ["community", "federation", "policies"],
                                                    [{"federation": "public", "canReceive": "false", "canForward": "false"}],
                                                    "",[])
    
    
if __name__ == '__main__':
    main()
