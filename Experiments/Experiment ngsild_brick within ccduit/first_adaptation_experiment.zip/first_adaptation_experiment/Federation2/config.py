FED_BROKER = "localhost"
FED_PORT = 1885
CONTEXT_BROKER_URL = "http://localhost:1029/ngsi-ld/v1/entities"
FEDERATION_ID = "urn:ngsi-ld:Federation:Federation2"
